import uuid
import os
import app
from app.catalog import main
from app import db
from app.catalog.models import Book, Publication, Shop
from flask import render_template, request, redirect, url_for, flash
from flask_login import login_required
from app.catalog.forms import EditBookForm,CreateBookForm
from PIL import Image



@main.route('/')
def display_books():
    books = Book.query.all()
    return render_template('home.html', books=books)

@main.route('/display/publisher/<publisher_name>')
def display_publisher(publisher_name):
    publisher = Publication.query.filter_by(name = publisher_name).first()
    publisher_books = Book.query.filter_by(pub_name = publisher_name).all()
    return render_template('publisher.html', publisher = publisher, publisher_books = publisher_books)

@main.route('/display/books/<author>')
def display_author(author):
    all_books = Book.query.filter_by(author = author).first()
    author_books = Book.query.filter_by(author = author).all()
    return render_template('author.html', all_books = all_books, author_books = author_books)

@main.route('/book/delete/<book_id>', methods=['GET', 'POST'])
@login_required
def delete_book(book_id):
    book = Book.query.get(book_id)
    if request.method == 'POST':
        db.session.delete(book)
        db.session.commit()
        flash('Book deleted successfully')
        return redirect(url_for('main.display_books'))
    return render_template('delete_book.html', book=book, book_id=book.id)


@main.route('/edit/book/<book_id>', methods=['GET', 'POST'])
@login_required
def edit_book(book_id):
    book = Book.query.get(book_id)
    form = EditBookForm(obj = book)
    if form.validate_on_submit():
        book.title = form.title.data
        book.format = form.format.data
        book.num_pages = form.num_pages.data
        db.session.add(book)
        db.session.commit()
        flash('Book Edited Successfully')
        return redirect(url_for('main.display_books'))
    return render_template('edit_book.html', form=form)

def save_picture(form_picture):
    unique_filename = str(uuid.uuid4())
    _, f_ext = os.path.splitext(form_picture.filename)
    image_name = unique_filename + f_ext
    picture_path = os.path.join(os.getcwd(),'app/static/img', image_name)
    output_size = (190,200)
    output_image = Image.open(form_picture)
    output_image.save(picture_path)

    return image_name

@main.route('/create/book/<pub_name>', methods=['GET', 'POST'])
@login_required
def create_book(pub_name):

    form = CreateBookForm()
    form.pub_name.data = pub_name  # pre-populates pub_name
    if form.validate_on_submit():
        if form.img_url.data:
            picture_file = save_picture(form.img_url.data)
        book = Book(title=form.title.data, author=form.author.data, avg_rating=form.avg_rating.data,
                    book_format=form.format.data, image=picture_file, num_pages=form.num_pages.data,
                    pub_name=form.pub_name.data)
        db.session.add(book)
        db.session.commit()
        flash('Book added successfully')
        return redirect(url_for('main.display_publisher', publisher_name=pub_name))
    return render_template('create_book.html', form=form, pub_name=pub_name)

@main.route('/display/shops/<book_id>', methods=['GET', 'POST'])
def display_shopDetails(book_id):
    book = Book.query.get(book_id)
    shops = Shop.query.filter_by(book_id = book_id).all()
    if not shops:
        flash('Sorry! This book is currently out of stock')
        return redirect(url_for('main.display_books'))
    return render_template('shop_details.html', book = book, shops = shops)

@main.route('/display/shops/city/<book_id>', methods=['GET', 'POST'])
def display_city(book_id):
    book = Book.query.get(book_id)
    shops = Shop.query.filter_by(book_id = book_id).all()
    if not shops:
        flash('Sorry! This book is currently out of stock')
        return redirect(url_for('main.display_books'))
    return render_template('shop_details.html', book = book, shops = shops)

