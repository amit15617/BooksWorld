DEBUG = True
SECRET_KEY = 'virus'
SQLALCHEMY_DATABASE_URI = 'postgres://postgres:amit@localhost/catalog_db'
SQLALCHEMY_TRACK_MODIFICATIONS = False