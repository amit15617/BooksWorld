# The Books World

# Overview 
The end product of this project will be a web application which in which user can login and explore the books available i.e (Books Title, Author Name
, Format, Average Rating, No Of Pages, Book Image and Publisher ID) and can list out all the books published by a particular publication. Books 
information is displayed on UI in seperate a card view. Publisher can add new books with all the required information, can edit and update the records
& can delete too.


# How To run
To run this project simply pull the code from master and run app.py file in a terminal. It will run on localhost:5000 by default.

1.	Software dependencies - PostgreSQL for storing data.
2. Languages - Python, HTML
3. Framework - Flask

# Database
1. Book table for storing - Id, Title, Author, Avg_rating, Format, Image, Num_pages, Publishing_Date and Pub_Id(this is a foreign key)
2. Publication table for storing- Id and Publication Name
3. User table for storing - Name , Email, Password